import React, { useEffect } from 'react';
import { Link, Navigate, useLocation } from 'react-router-dom'; 
import "./AdminHome.css"
import {useParams} from "react-router-dom"
import { Button } from '@mui/material';
import { UseAppContext } from '../../../Contexts/app-context';

const AdminHome = () => {
  const {loggedIn, currentUserParsed} = UseAppContext()
  const location = useLocation();
  const isViewProductsPage = location.pathname.includes('/view-products');
  const isCreateProductPage = location.pathname.includes('/create-product');
  const {role} = currentUserParsed
  // const buttonStyle = {
  //   backgroundColor: isCreateProductPage
  //     ? 'var(--background-color-8)'
  //     : 'var(--background-color)',
  //   color: isCreateProductPage ? 'var(--color3)' : 'var(--color)',
  //   '&:hover': {
  //     backgroundColor: isCreateProductPage
  //       ? 'var(--background-color)'
  //       : 'var(--background-color-8)',
  //     color: isCreateProductPage ? 'var(--color4)' : 'var(--color)',
  //   },
  // };


  useEffect(() => {
    const timer = setTimeout(() => {
      if (loggedIn === "false" || role !== "admin") {
        return  <Navigate to='/' /> 
      }
    }, 2000); 
    return () => clearTimeout(timer);
  }, []); 

  return (
    <div className="admin-home">
      <h3 className='admin-title'>Welcome, Admin!</h3>
      
      <div className="action-buttons">
        <Link to="/admin/view-products" className="view-button">
        <Button 
        // sx={{
        //   backgroundColor: 'var(--background-color-8)',
        //   color: 'var(--color3)',
        //   '&:hover': {
        //     backgroundColor: 'var(--background-color)',
        //     color: 'var(--color4)'
        //   },
        // }}
        sx={{
          backgroundColor: isViewProductsPage
          ? 'var(--background-color)'
          : 'var(--background-color-8)',
        color: isViewProductsPage ? 'var(--color)' : 'var(--color3)',
        '&:hover': {
          backgroundColor: isViewProductsPage
            ? 'var(--background-color)'
            : 'var(--background-color-8)',
          color: isViewProductsPage ? 'var(--color4)' : 'var(--color)',
        }
        }}
        >View Products</Button>
        </Link>
        <Link to="/admin/create-product" >
          <Button 
          sx={{
            backgroundColor: isCreateProductPage
            ? 'var(--background-color)'
            : 'var(--background-color-8)',
          color: isCreateProductPage ? 'var(--color)' : 'var(--color3)',
          '&:hover': {
            backgroundColor: isCreateProductPage
              ? 'var(--background-color)'
              : 'var(--background-color-8)',
            color: isCreateProductPage ? 'var(--color4)' : 'var(--color)',
          }
          }}
          >Create Product</Button>
        </Link>
      </div>
    </div>
  );
};

export default AdminHome;
