import React from 'react'
import { UseAppContext } from '../../Contexts/app-context'
import "./Profile.css"
import { capitalizeFirstLetter, formattedPrice } from '../../resourses/functions'
import { Navbar, Sidebar } from '../../Components'
import { Link } from 'react-router-dom'

const Profile = () => {
    const {currentUserParsed, orders} = UseAppContext()
    const {email,firstname,lastname,role,_id} = currentUserParsed
   if(currentUserParsed){
    console.log(currentUserParsed)
   }
    
   const calculateDate=(createdAt)=>{
    const date = new Date(createdAt);
    const year = date.getFullYear();
    const month = date.getMonth() + 1; 
    const day = date.getDate();
    const dateString = `${year}-${month.toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`;
    return dateString
}

  return (
    <>
     <Navbar />
      <Sidebar />
      <div className='profile'>
        <h2>{currentUserParsed.firstname && `Welcome ${capitalizeFirstLetter(firstname)} ${capitalizeFirstLetter(lastname)}`}</h2>
        <h3>Your orders</h3>
        {
            orders.map(order =>{
                const {_id, createdAt, orderProducts, total} = order
                const dateCreated = calculateDate(createdAt)
                return<div key={_id} className='orderContainer'>
                    <h4>{dateCreated}</h4>
                     <table>
                    <thead>
                        <tr>
                        <th className='cell'></th>
                        <th className='cell'></th>
                        <th className='cell'>Quantity</th>
                        <th className='cell'>Unit Price</th>
                        </tr>
                    </thead>
                    <tbody>
                    {
                        orderProducts.map(item =>{ 
                            const {_id, productId, productAmount, productName, productPrice,
                                productImage} = item
                            return<tr key={_id}>
                                    <td className='cell'>
                                    <Link to={`/product/${productId}`} className='order-links'> 
                                        <img src={productImage} alt={productName} className='order-image' />
                                    </Link>
                                    </td>
                                    <td className='cell order-name'>
                                        <Link to={`/product/${productId}`} className='order-links'>{productName}</Link>
                                    </td>
                                    <td className='cell'>{productAmount}</td>
                                    <td className='cell'>{formattedPrice(productPrice)}</td>
                            </tr>
                        })
                    }
                    </tbody>
                    </table>
                    <h3 className='order-total'>Order total: {formattedPrice(total)}</h3>
                </div>
            })
        }
      </div> 
    </>
  )
}

export default Profile