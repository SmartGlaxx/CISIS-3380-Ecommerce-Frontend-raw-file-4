const API = 'http://localhost:5000'


export default API