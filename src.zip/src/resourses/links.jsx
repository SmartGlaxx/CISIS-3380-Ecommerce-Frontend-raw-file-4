import { FaHouse, FaCartShopping, FaStore } from "react-icons/fa6"
export const links = [
    {
        id: 1,
        name: "Homepage",
        url: "/",
        icon: <FaHouse />,
        color: "var(--color4)"
    },
    {
        id: 2,
        name: "Products",
        url: "/products",
        icon: <FaStore />,
        color: "var(--color4)"
    },
    {
        id: 3,
        name: "Cart",
        url: "/cart",
        icon: <FaCartShopping />,
        color: "var(--color4)"
    }
]