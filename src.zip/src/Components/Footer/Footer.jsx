import React from 'react'
import "./footer.css"

const Footer = () => {
  return (
    <div className='footer'>
         <div className="footer-column">
        <h3>Column 1</h3>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ac justo quis mi dignissim bibendum.</p>
        </div>
        <div className="footer-column">
          <h3>Column 2</h3>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ac justo quis mi dignissim bibendum.</p>
        </div>
        <div className="footer-column">
          <h3>Column 3</h3>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ac justo quis mi dignissim bibendum.</p>
        </div>
    </div>
  )
}

export default Footer
