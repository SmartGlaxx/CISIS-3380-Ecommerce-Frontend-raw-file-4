const LOADING = 'LOADING'; const CURRENTUSER = "CURRENTUSER"
const ALERT='ALERT';  const SETSIDEBAR = 'SETSIDEBAR' ; 
const CURRENTUSERPARSED = 'CURRENTUSERPARSED' ; 
const SET_PRODUCTS = "SET_PRODUCTS"; const LOGGEDIN = "LOGGEDIN";
const SET_FILTERED_PRODUCTS = "SET_FILTERED_PRODUCTS"; const SET_ORDERS = "SET_ORDERS";
const SET_PRODUCT = "SET_PRODUCT"; const ADD_TO_CART = "ADD_TO_CART"
const PRODUCT_VIEW = "PRODUCT_VIEW"; const CHANGE_SORT = "CHANGE_SORT";
const SORT_PRODUCTS = "SORT_PRODUCTS"; const SET_FILTER_VALUES = "SET_FILTER_VALUES";
const CLEAR_FILTERS = "CLEAR_FILTERS"
const FILTER_PRODUCTS = "FILTER_PRODUCTS"; const SET_PRICES = "SET_PRICES"
const DECREASE_CART_QUNTITY = "DECREASE_CART_QUNTITY"; const INCREASE_CART_QUNTITY = "INCREASE_CART_QUNTITY";
const DELETE_CART_ITEM = "DELETE_CART_ITEM"; const CLEAR_CART = "CLEAR_CART";


const reducer = (state, action)=>{
    switch(action.type){
        case LOADING: 
            return {...state, loading: action.payload }
        case LOGGEDIN:
            return{...state, loggedIn : action.payload}

        case ALERT:
            return {...state, alert : action.payload}

        case CURRENTUSERPARSED :
            return {...state, currentUserParsed : action.payload}
            



        case SET_PRODUCTS:
            const featured = action.payload.filter((product)=> product.featured == true)
            return {...state, products: action.payload, featured: featured}
        case SET_FILTERED_PRODUCTS:
            return {...state, filteredProducts: action.payload}
            
        case SET_PRODUCT:
            return {...state, product: action.payload}
        
        case SET_ORDERS:
            return {...state, orders: action.payload}

        case SET_PRICES:
            return {...state, filters:{...state.filters, price: action.payload, highest_price: action.payload}}

        case ADD_TO_CART:
            const items  = state.cart;
            let newItem = {}
            
            let {id, productName, selectedColor, quantity, product} = action.payload
            const itemInCart = items.find(item => item.id == id + "_" +selectedColor)
            if(itemInCart){
                
                const temp = state.cart.map(cartItem =>{
                    if(cartItem.id == id+ "_" +selectedColor){
                        let newQuantity = cartItem.quantity + quantity
                        if(newQuantity > cartItem.inventory){
                            newQuantity = cartItem.inventory
                        }
                        return {...cartItem, quantity: newQuantity}
                    }else{
                        return cartItem
                    }
                })
                return {...state, cart: temp}
            }else{
                if(quantity > product.inventory){
                    quantity == product.inventory
                }
                newItem = {
                    id: id + "_" + selectedColor, 
                    productName, 
                    selectedColor, 
                    quantity,
                    inventory: product.inventory,
                    image: product.productImages[0],
                    price: product.price
                }

            }
            const newCart = [...state.cart, newItem]
            // localStorage.setItem('Cart',JSON.stringify())
            return {...state, cart: newCart}
        case PRODUCT_VIEW:
            return {...state, view: action.payload}
        
        case CHANGE_SORT:
            return {...state, sort: action.payload}
        
        case SORT_PRODUCTS:
            const {filteredProducts} = state
            let tempProducts = [...filteredProducts]
            switch(action.payload){
                case "price-lowest":
                tempProducts = filteredProducts.sort((a,b)=>a.price - b.price)
                break;
                case "price-highest":
                tempProducts = filteredProducts.sort((a,b)=>b.price - a.price)
                break;
                case "name-a":
                tempProducts = filteredProducts.sort((a,b)=>a.productName.localeCompare(b.productName))
                break;
                case "name-z":
                tempProducts = filteredProducts.sort((a,b)=>b.productName.localeCompare(a.productName))
                break;
            }
            return {...state, filteredProducts: tempProducts}

        case SET_FILTER_VALUES:
            const name = action.payload.name
            const value = action.payload.value
            return {...state, filters:{...state.filters, [name]: value}}
        
        
        case FILTER_PRODUCTS:
            const {products} = state
            let temp = [...products]
            const {search_text, category, company, price, highest_price, color, shipping} = state.filters
            if(!search_text == ""){
                temp = temp.filter(product => product.productName.toLowerCase().startsWith(search_text))
            }
            if(category !== "All"){
                temp = temp.filter(product => product.productCategory.toLowerCase() == category.toLowerCase())
            }
            if(company !== "All"){
                temp = temp.filter(product => product.manufacturer.toLowerCase() == company.toLowerCase())
            }
            if(price !== highest_price){
                temp = temp.filter(product => product.price < price)
            }
            if(color !== "All"){
                temp = temp.filter(product => product.colors.find(c => c == color))
            }
            if(shipping == true){
                temp = temp.filter(product => product.freeShipping == true)
            }
            return {...state, filteredProducts: temp}

        case CLEAR_FILTERS:
            return {...state, filters:{
                ...state.filters,
                search_text:"",
                category: "All",
                company: "All",
                color: "All",
                price: state.filters.highest_price,
                shipping: false
            }}
        
        case DECREASE_CART_QUNTITY:
            const {id: cartDecreaseId} = action.payload
            const decreasedCart = state.cart.map(item => {
                if(item.id == cartDecreaseId){
                    let newDecreaseValue = item.quantity-1
                    if(newDecreaseValue < 1){
                        newDecreaseValue = 1
                    }
                    return {...item, quantity: newDecreaseValue}
                }
                return {...item}
            })
            return{...state, cart:decreasedCart}
        
        case INCREASE_CART_QUNTITY:
            const {id: cartIncreaseId, inventory: cartIncreaseInventory} = action.payload
            const inncreasedCart = state.cart.map(item =>{
                if(item.id == cartIncreaseId){
                    let newIncreaseValue = item.quantity + 1
                    if(newIncreaseValue > cartIncreaseInventory){
                        newIncreaseValue = cartIncreaseInventory
                    }
                    return {...item, quantity: newIncreaseValue}
                }
                return {...item}
            })
            return {...state, cart: inncreasedCart}

        case DELETE_CART_ITEM:
            const deleteCartItemId = action.payload
            const remainingCartItems = state.cart.filter(item => {
                return item.id !== deleteCartItemId
            })
           
            return {...state, cart: remainingCartItems}

        case CLEAR_CART:
            return {...state, cart:[]}


        default:
            return {...state}
    }
    return state
}

export default reducer
